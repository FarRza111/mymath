# mymath

A simple Python package that provides an `add(a, b)` function.
